
from flask import Flask, Response

import time
import numpy as np
import requests
import re
from keras.models import load_model
import cv2


np.set_printoptions(suppress=True)

model = load_model("keras_model.h5", compile = False)

class_names = open("labels.txt", "r",encoding='UTF8').readlines()

def extract_korean(text):
    korean_pattern = re.compile('[가-힣]+')
    return ''.join(korean_pattern.findall(text))

class_names = [extract_korean(text) for text in class_names]

print(class_names)



app = Flask(__name__)

def generate_frames(rtmp_url):
    
    rtmp_url1 = 'https://usms-media.serveftp.com/video/hls/live/'+'0e798b6c-2b80-47d6-beae-95435399fb7d'+'/index.m3u8'
    spring_server_url = 'https://usms.serveftp.com/live-streaming/accidents'

    cap = cv2.VideoCapture(rtmp_url1)

    


    last_message_time = time.time()
    message_interval = 10  # 1초마다 메시지 보내기
    tmp =0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        ret, buffer = cv2.imencode('.jpg', frame)
        if not ret:
            break

        # 이미지를 바이트로 변환하여 클라이언트에 전송
        frame_bytes = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        
        current_time = time.time()
        if current_time - last_message_time >= message_interval:

#####################################################################################################  Ai 모델

            image = cv2.resize(frame, (224, 224), interpolation=cv2.INTER_AREA)


            image = np.asarray(image, dtype=np.float32).reshape(1, 224, 224, 3)

            image = (image /127.5) - 1

            prediction = model.predict(image)
            print(prediction,"----------------------------------")
            index = np.argmax(prediction)
            class_name = class_names[index]
            confidence_score = prediction[0][index]

            print("Class:", class_name, end="")
            print("Confidence Score:", str(np.round(confidence_score * 100))[:-2], "%")
            
#######################################################################################################


####################################################################################################### 여기서부터 prediction 이 이상행동일때 처리하는 로직 
            timestamp = int(time.time())
            print("Sending message every",tmp,timestamp*1000)
            tmp=tmp+1
            payload = {
                "streamKey": rtmp_url,
                "behavior": 0,
                "startTimestamp": timestamp
            }
            headers = {'Content-Type': 'application/json'}
            response = requests.post(spring_server_url, json=payload, headers=headers)
            time.sleep(50)


            last_message_time = current_time #-----> 초단위로 동작시키는거 나중에 모델 초단위 프레임넣을때 유용함.
 ##########################################################################################################       
    print('exit')
    cap.release()


@app.route('/api/video/<path:rtmp_url>')
def video_feed(rtmp_url):
    return Response(generate_frames(rtmp_url), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
